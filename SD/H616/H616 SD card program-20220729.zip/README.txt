    File description:
    WhatsMiner-SDCard-Burn-Image-M3x-h616-20220729.11.img: the image file to be burned.
    WhatsMiner-SDCard-Burn-Image-M3x-h616-20220729.11.md5: the MD5 file contains the MD5 value of the image file.

    In Windows, press Windows+R to open "Run" box. Type "cmd" and then click "OK" to 
    open a regular command prompt. And run following command to perform MD5 verification:
    certutil -hashfile [path of WhatsMiner-SDCard-Burn-Image-M3x-h616-20220729.11.img] MD5

    For example, if the image file is unzipped to D drive(D:\), the command is:
    certutil -hashfile D:\WhatsMiner-SDCard-Burn-Image-M3x-h616-20220729.11.img MD5

    If the MD5 value is different from the value in WhatsMiner-SDCard-Burn-Image-M3x-h616-20220729.11.md5, 
    the image file is damaged. In this case, please download it again.
